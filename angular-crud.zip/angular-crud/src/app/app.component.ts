import { Component } from '@angular/core';
import { Producto } from './models/producto';


let productosArray: Producto[] = [
  { id: 1, nombre: "Camiseta", precio: 12.44, unidades: 12 },
  { id: 2, nombre: "Pantalones", precio: 10.99, unidades: 1 },
  { id: 3, nombre: "Chaqueta", precio: 33.99, unidades: 18 },
];

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


export class AppComponent {

  title = 'angular-crud';
}
