import { Component, OnInit } from '@angular/core';
import { Producto } from '../models/producto';

@Component({
  selector: 'app-mostrarproductos',
  templateUrl: './mostrarproductos.component.html',
  styleUrls: ['./mostrarproductos.component.css']
})
export class MostrarproductosComponent implements OnInit {

  productosArray: Producto[] = [
    { id: 1, nombre: "Camiseta", precio: 12.44, unidades: 12 },
    { id: 2, nombre: "Pantalones", precio: 10.99, unidades: 1 },
    { id: 3, nombre: "Chaqueta", precio: 33.99, unidades: 18 },
  ];

  productoSeleccionado: Producto = new Producto();


  agregareditar() {

    if (this.productoSeleccionado.id === 0) {
      this.productoSeleccionado.id = this.productosArray.length + 1;
      this.productosArray.push(this.productoSeleccionado);
    }


    this.productoSeleccionado = new Producto();
  }

  editar(producto: Producto) {
    this.productoSeleccionado = producto;
  }

  eliminar() {
    this.productosArray = this.productosArray.filter(x => x != this.productoSeleccionado);
    this.productoSeleccionado = new Producto();
  }

  constructor() { }

  ngOnInit() {
  }

}
